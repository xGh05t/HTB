#!/usr/bin/env python3

import json
import signal
import websocket
from flask import *


app = Flask(__name__)


@app.route("/")
def index():
    ws = websocket.create_connection('ws://qreader.htb:5789/version')
    params = request.args['params']
    #Need to make sure it renders the ' properly
    params = params.replace("'","\'")
    print(params)
    ws.send(json.dumps({'version': params}))
    data = ws.recv()
    print(data)
    return data


if __name__ == "__main__":
    app.run(debug=True)
